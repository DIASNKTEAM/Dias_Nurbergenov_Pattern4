public interface Player {
    public void action();
}
