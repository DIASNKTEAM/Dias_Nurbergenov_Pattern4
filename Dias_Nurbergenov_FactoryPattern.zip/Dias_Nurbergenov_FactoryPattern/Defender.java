public class Defender implements Player {
    @Override
    public void action() {
        System.out.println("Defender tackles the ball and destroy the opponents");
    }
}
