public class Midfielder implements Player {
    @Override
    public void action() {
        System.out.println("Midfielders turn into magicians and help attackers to destroy the opponents");
    }
}
