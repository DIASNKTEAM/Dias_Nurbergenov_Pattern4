public class Attacker implements Player {

    @Override
    public void action() {
        System.out.println("Attackers easily destroy the opponents with their cold-blooded heads.");
    }
}
