public interface Factory {
    public Player createDefender();
    public Player createMidfielder();
    public Player createAttacker();
}
