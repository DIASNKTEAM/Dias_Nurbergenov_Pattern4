package AbstractFactoryPattern;

public class ESUFOBossEngine implements ESEngine{
    public String toString(){
        return "2000 mph";
    }
}
