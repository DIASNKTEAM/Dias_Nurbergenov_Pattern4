package AbstractFactoryPattern;

public class ESUFOGun implements ESWeapon{
    public String toString(){
        return "20 damage";
    }
}
