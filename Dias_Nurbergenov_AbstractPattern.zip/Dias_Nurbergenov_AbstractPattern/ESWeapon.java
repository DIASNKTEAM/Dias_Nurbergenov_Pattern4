package AbstractFactoryPattern;

public interface ESWeapon {
    public String toString();
}
