package AbstractFactoryPattern;

public interface ESEngine {
    public String toString();
}
