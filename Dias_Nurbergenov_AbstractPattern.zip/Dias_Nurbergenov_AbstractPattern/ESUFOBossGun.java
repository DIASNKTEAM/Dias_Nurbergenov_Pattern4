package AbstractFactoryPattern;

public class ESUFOBossGun implements ESWeapon{
    public String toString(){
        return "40 damage";
    }
}
