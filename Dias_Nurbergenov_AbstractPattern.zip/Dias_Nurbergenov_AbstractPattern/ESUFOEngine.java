package AbstractFactoryPattern;

public class ESUFOEngine implements ESEngine{
    public String toString(){
        return "1000 mph";
    }
}
